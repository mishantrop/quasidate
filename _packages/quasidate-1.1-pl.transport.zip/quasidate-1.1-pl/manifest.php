<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'eb4fbdef4969adfefdcddb70d693730e',
      'native_key' => 'quasidate',
      'filename' => 'modNamespace/63eef6baf2430403f11af9152b9f7b87.vehicle',
      'namespace' => 'quasidate',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '735b935b302b990a10960f366d556e2d',
      'native_key' => 1,
      'filename' => 'modCategory/03729ca1894b6c17e48f517a2bfa906a.vehicle',
      'namespace' => 'quasidate',
    ),
  ),
);